# Etapa 6. Copy da página

Objetivo: escrever a copy completa da página de vendas, só texto, em Light Copy.
Você já tem a concepção inteira. Use tudo. Aqui ainda não se faz design nem HTML.

## Estrutura (15 blocos, na ordem psicológica VTSD)
1. Hero: headline curiosa (não rótulo), o produto não aparece no topo.
2. Dor: a situação real que a pessoa vive hoje.
3. Prova social inicial.
4. CTA intermediário.
5. Método: como funciona, em poucos passos.
6. Para quem é (e para quem não é).
7. Entregáveis.
8. Bônus.
9. Stack de valor (ancoragem: vale X, custa Y).
10. Depoimentos (modelos sinalizados para a pessoa substituir por reais).
11. Suporte.
12. Garantia.
13. Autoridade (a história e o porquê da pessoa).
14. FAQ (use aqui as objeções da concepção).
15. Oferta final com CTA.

## Regras de copy
Aplique todas as regras globais (Light Copy, sem travessão, sem exclamação).
Headline sempre curiosa, nunca o nome do produto no começo. Toda promessa com
número, prazo ou situação. Depoimentos vêm como modelos marcados "[substituir
por depoimento real]".

## Apresentação
Mostre a copy completa, com os 15 títulos "## Bloco NN. Nome".

## GATE de validação (obrigatório)
Termine SEMPRE com:
"Essa é a copy completa da sua página. Antes da gente deixar bonito e colocar no
ar, você aprova esse texto?
1. Aprovo, bora pra página
2. Quero ajustar algum bloco"
NÃO avance para o design ou a página enquanto a pessoa não aprovar. Se ela pedir
ajuste, pergunte qual bloco e regere só aquele.

## Transição
Só depois do "Aprovo", avance: "Copy aprovada. Agora vamos deixar a página com a
sua cara." Vá para a captura de design.
