# Crie Seu Produto com a Primia: montagem em 3 passos

Você recebeu uma pasta com os arquivos de um guia. Em 2 minutos ele vira um
Project no seu Claude, e aí é só conversar. Não precisa saber nada técnico.

## Passo 1. Crie o Project
1. Entre em https://claude.ai (precisa estar logado).
2. No menu da esquerda, clique em "Projects" e depois em "New project".
3. Dê o nome: Crie Seu Produto com a Primia.

## Passo 2. Cole as instruções
1. Dentro do Project, procure o campo de instruções (pode aparecer como
   "Set custom instructions", "Instructions" ou "What are you working on").
2. Escolha qual instrução colar (use só uma):
   - `00-INSTRUCAO-MAE.md`: o guia completo (nicho, pesquisa, 20 ideias,
     formato, oferta, copy, página, anúncios, vídeo, projeção). Para fazer com
     calma, em casa.
   - `00-INSTRUCAO-MAE-EXPRESSA.md`: a versão curta e rápida, que vai direto até
     a página publicada. Use esta para o evento ao vivo.
3. Copie TODO o conteúdo da que escolheu e cole nesse campo. Salve.

## Passo 3. Anexe os arquivos de conhecimento
1. No Project, procure a área de conhecimento (aparece como "Project knowledge",
   "Add content" ou um ícone de clipe/anexo).
2. Selecione e suba TODOS os 14 arquivos que estão dentro da pasta
   `conhecimento/`. Pode arrastar todos de uma vez.
3. Espere terminar de subir.

## Pronto. Agora teste
1. Abra uma conversa nova dentro do Project.
2. Escreva apenas: oi
3. O guia vai te dar as boas-vindas e te conduzir passo a passo, sozinho.

### Dica para o teste funcionar 100%
Antes de começar a conversa, deixe a busca na web ATIVADA na conversa (o guia
pesquisa o mercado de verdade num dos passos). Se não achar onde ativar, pode
seguir mesmo assim: o guia avisa e trabalha sem dados atualizados.

### Se o Claude reclamar que as instruções são grandes demais
Raro, mas pode acontecer em algumas contas. Nesse caso me avise: existe um
plano B (dividir em 2 Projects) que eu te passo na hora.
